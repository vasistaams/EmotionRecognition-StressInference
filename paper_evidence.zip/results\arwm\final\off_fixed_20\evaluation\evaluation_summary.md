# ARWM Variant Evaluation

- Evaluated at (UTC): 2026-10-20T17:34:15.419864+00:00
- Dataset/split: FER2013 official test
- Samples in split: 7178
- Device: cuda
- Image size / batch size: 160 / 8
- Configuration: `configs\arwm\off_20.yaml`
- Comparison status: **incomplete_or_legacy_checkpoints_not_a_controlled_ablation**
- Existing checkpoint metrics embedded in checkpoints are validation metrics, not test results.

| Mode | Status | N | Accuracy | Balanced acc. | Macro F1 | Weighted F1 | ms/image | images/s | Load seconds |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| off | complete_test | 7178 | 0.6998 | 0.6880 | 0.6851 | 0.7020 | 11.1387 | 89.7774 | 2.4373 |
| fixed | complete_test | 7178 | 0.7087 | 0.6938 | 0.6950 | 0.7075 | 11.7167 | 85.3485 | 2.1779 |

fixed region weights: mean=[0.3333, 0.3333, 0.3333], std=[0.0, 0.0, 0.0], normalization error=2.98e-08. These are internal model signals, not explanations.
| adaptive | complete_test | 7178 | 0.7087 | 0.7099 | 0.6846 | 0.7084 | 11.6980 | 85.4848 | 2.3321 |

adaptive region weights: mean=[0.1222, 0.1187, 0.7591], std=[0.1693, 0.2216, 0.2889], normalization error=1.42e-07. These are internal model signals, not explanations.

- Off vs Adaptive comparison: **unavailable_or_training_conditions_unverified**
- Adaptive minus Off: accuracy +0.892 pp; macro-F1 -0.053 pp.
A result is not a controlled ARWM ablation unless the variants were trained with the same data split, seed, model-selection rule, and training hyperparameters. Unavailable checkpoints are not substituted with validation scores.

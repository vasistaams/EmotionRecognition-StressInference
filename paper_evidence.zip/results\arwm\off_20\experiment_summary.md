# ARWM-Off 20-Epoch Run

- Status: completed 20/20 epochs.
- Seed: 42.
- Best validation checkpoint: `checkpoints\arwm_variants\off_20\best_model.pth` (epoch 16).
- Final-epoch checkpoint: `checkpoints/arwm_variants/off_20/checkpoint_epoch020.pth`.
- Stored checkpoint metrics are validation results from training; they are not test-set evaluation results.
- Official FER2013 test-set evaluation: not yet run.
- Training log: `logs\arwm_variants\off_20\swin_fane_run1_20261020_132509\train.log`.

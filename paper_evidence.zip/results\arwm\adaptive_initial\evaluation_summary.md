# ARWM Variant Evaluation

- Dataset/split: FER2013 official test
- Samples in split: 7178
- Device: cuda
- Image size / batch size: 160 / 1
- Configuration: `configs\config_arwm_50.yaml`
- Comparison status: **incomplete_or_legacy_checkpoints_not_a_controlled_ablation**
- Existing checkpoint metrics embedded in checkpoints are validation metrics, not test results.

| Mode | Status | N | Accuracy | Balanced acc. | Macro F1 | Weighted F1 | ms/image | images/s | Load seconds |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| off | unavailable | — | — | — | — | — | — | — | — |

off limitation: No trained checkpoint is available for this mode. This variant was not evaluated.
| fixed | unavailable | — | — | — | — | — | — | — | — |

fixed limitation: No trained checkpoint is available for this mode. This variant was not evaluated.
| adaptive | partial_smoke | 16 | 0.5000 | 0.5000 | 0.1333 | 0.6667 | 98.4833 | 10.1540 | 4.5095 |

A result is not a controlled ARWM ablation unless the variants were trained with the same data split, seed, model-selection rule, and training hyperparameters. Unavailable checkpoints are not substituted with validation scores.

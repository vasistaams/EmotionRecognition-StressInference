# ARWM Variant Evaluation

- Evaluated at (UTC): 2026-10-20T07:34:56.352051+00:00
- Dataset/split: FER2013 official test
- Samples in split: 7178
- Device: cuda
- Image size / batch size: 160 / 1
- Configuration: `configs\config_arwm_50.yaml`
- Comparison status: **incomplete_or_legacy_checkpoints_not_a_controlled_ablation**
- Existing checkpoint metrics embedded in checkpoints are validation metrics, not test results.

| Mode | Status | N | Accuracy | Balanced acc. | Macro F1 | Weighted F1 | ms/image | images/s | Load seconds |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| off | unavailable | — | — | — | — | — | — | — | — |

off limitation: No trained checkpoint is available for this mode. This variant was not evaluated.
| fixed | unavailable | — | — | — | — | — | — | — | — |

fixed limitation: No trained checkpoint is available for this mode. This variant was not evaluated.
| adaptive | complete_test | 7178 | 0.7087 | 0.7099 | 0.6846 | 0.7084 | 64.5631 | 15.4887 | 64.9910 |

- Off vs Adaptive comparison: **unavailable_or_training_conditions_unverified**; no verified Off checkpoint is available.

A result is not a controlled ARWM ablation unless the variants were trained with the same data split, seed, model-selection rule, and training hyperparameters. Unavailable checkpoints are not substituted with validation scores.

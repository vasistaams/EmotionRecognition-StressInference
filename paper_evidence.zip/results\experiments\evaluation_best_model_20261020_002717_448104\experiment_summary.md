# FER2013 official test evaluation

- Evaluation date: 2026-10-20T00:27:17.448104+05:30
- Checkpoint: `best_model.pth`
- Checkpoint epoch: 18
- Configuration: `C:\Users\vedag\OneDrive\Desktop\EmotionRecognition-StressInference\configs\arwm\adaptive.yaml`
- Dataset split: official FER2013 test folder (`C:\Users\vedag\OneDrive\Desktop\EmotionRecognition-StressInference\data\fer2013\test`)
- Evaluated samples: 7178
- Device: cuda
- Stored checkpoint metrics are historical checkpoint metadata, not the newly evaluated test metrics below.

## Newly evaluated metrics

| Metric | Value |
|---|---:|
| accuracy | 0.708693229311786 |
| balanced_accuracy | 0.7099115631388825 |
| macro_precision | 0.6761151010994338 |
| macro_recall | 0.7099115631388825 |
| macro_f1 | 0.6845586006686754 |
| roc_auc_ovr_macro | 0.9012943703317806 |
| test_loss | 1.1375752906342276 |

Accuracy, balanced accuracy, precision, recall, F1, and ROC-AUC are fractions in [0, 1]. Test loss is unweighted mean cross-entropy without label smoothing. Precision/recall/F1 in the CSV report are per-class fractions; support is a sample count.

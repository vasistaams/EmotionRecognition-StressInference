# ARWM Variant Evaluation

- Evaluated at (UTC): 2026-10-20T07:39:43.810180+00:00
- Dataset/split: FER2013 official test
- Samples in split: 7178
- Device: cuda
- Image size / batch size: 160 / 1
- Configuration: `configs\config_arwm_50.yaml`
- Comparison status: **incomplete_or_legacy_checkpoints_not_a_controlled_ablation**
- Existing checkpoint metrics embedded in checkpoints are validation metrics, not test results.

| Mode | Status | N | Accuracy | Balanced acc. | Macro F1 | Weighted F1 | ms/image | images/s | Load seconds |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| off | unavailable | — | — | — | — | — | — | — | — |

off limitation: No trained checkpoint is available for this mode. This variant was not evaluated.
| fixed | unavailable | — | — | — | — | — | — | — | — |

fixed limitation: No trained checkpoint is available for this mode. This variant was not evaluated.
| adaptive | partial_smoke | 16 | 0.5000 | 0.5000 | 0.1333 | 0.6667 | 112.0789 | 8.9223 | 2.8536 |

adaptive region weights: mean=[0.176, 0.328, 0.496], std=[0.2009, 0.3339, 0.292], normalization error=7.08e-08. These are internal model signals, not explanations.

- Off vs Adaptive comparison: **unavailable_or_training_conditions_unverified**
A result is not a controlled ARWM ablation unless the variants were trained with the same data split, seed, model-selection rule, and training hyperparameters. Unavailable checkpoints are not substituted with validation scores.

# ARWM-Off and ARWM-Fixed 20-Epoch Experiments

- Evaluation timestamp (UTC): 2026-10-20T17:34:15.419864+00:00
- Evaluation split: FER2013 official test; 7,178 images.
- Device: NVIDIA GeForce RTX 3050 6GB Laptop GPU (cuda); image size 160; batch size 8.
- The Off and Fixed models were each trained for 20 epochs with seed 42 and the dedicated configs listed below.
- The Adaptive model is the pre-existing checkpoint at `checkpoints/best_model.pth`; its training provenance is unknown, so the three-way comparison is exploratory, not a controlled ablation.
- All rows below are test-set evaluation results from the same evaluator invocation. The pre-existing Adaptive result file was separately verified and matches this invocation.

## Run and checkpoint status

| Variant | Training config | Epochs completed | Best checkpoint epoch | Checkpoint | Best validation accuracy |
|---|---|---:|---:|---|---:|
| Off | `configs/arwm/off_20.yaml` | 20/20 | 16 | `checkpoints\arwm_variants\off_20\best_model.pth` | 71.23% |
| Fixed | `configs/arwm/fixed_20.yaml` | 20/20 | 17 | `C:\Users\vedag\OneDrive\Desktop\EmotionRecognition-StressInference\checkpoints\arwm_variants\fixed_20\best_model.pth` | 71.67% |
| Adaptive | Legacy Adaptive training config/provenance unavailable | unknown | 18 | `checkpoints\best_model.pth` | 70.95% |

Off and Fixed used the same base training settings (`configs/config_arwm_50.yaml`), FER2013 split, class order, preprocessing, seed 42, and 20-epoch cap; only ARWM mode and isolated output paths differ. Adaptive provenance cannot be verified.

## Official test-set comparison

| Variant | N | Accuracy | Balanced acc. | Macro precision | Macro recall | Macro-F1 | Weighted-F1 | Test loss | Latency (ms/image) | Throughput (images/s) | Peak PyTorch allocated (MiB) | Parameters |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Off | 7,178 | 69.98% | 68.80% | 68.52% | 68.80% | 68.51% | 70.20% | 1.0450 | 11.1387 | 89.78 | 491.0 | 101,192,640 |
| Fixed | 7,178 | 70.87% | 69.38% | 70.14% | 69.38% | 69.50% | 70.75% | 1.0456 | 11.7167 | 85.35 | 830.9 | 102,244,288 |
| Adaptive | 7,178 | 70.87% | 70.99% | 67.61% | 70.99% | 68.46% | 70.84% | 1.1376 | 11.6980 | 85.48 | 834.9 | 102,638,019 |

## Per-class test metrics

| Class | Variant | Precision | Recall | F1 | Support |
|---|---|---:|---:|---:|---:|
| anger | Off | 60.69% | 66.39% | 63.41% | 958 |
| disgust | Off | 63.87% | 68.47% | 66.09% | 111 |
| fear | Off | 60.80% | 51.95% | 56.03% | 1,024 |
| happiness | Off | 91.85% | 83.88% | 87.68% | 1,774 |
| sadness | Off | 56.99% | 61.75% | 59.28% | 1,247 |
| surprise | Off | 82.12% | 79.06% | 80.56% | 831 |
| neutral | Off | 63.30% | 70.07% | 66.51% | 1,233 |
| anger | Fixed | 59.22% | 69.42% | 63.91% | 958 |
| disgust | Fixed | 74.51% | 68.47% | 71.36% | 111 |
| fear | Fixed | 61.78% | 46.09% | 52.80% | 1,024 |
| happiness | Fixed | 90.62% | 88.28% | 89.43% | 1,774 |
| sadness | Fixed | 57.01% | 62.31% | 59.54% | 1,247 |
| surprise | Fixed | 79.33% | 82.67% | 80.97% | 831 |
| neutral | Fixed | 68.51% | 68.45% | 68.48% | 1,233 |
| anger | Adaptive | 67.21% | 60.33% | 63.59% | 958 |
| disgust | Adaptive | 50.29% | 79.28% | 61.54% | 111 |
| fear | Adaptive | 65.55% | 47.75% | 55.25% | 1,024 |
| happiness | Adaptive | 92.42% | 84.55% | 88.31% | 1,774 |
| sadness | Adaptive | 55.87% | 66.00% | 60.51% | 1,247 |
| surprise | Adaptive | 76.85% | 87.48% | 81.82% | 831 |
| neutral | Adaptive | 65.09% | 71.53% | 68.16% | 1,233 |

## Verified prior Adaptive result

- Existing saved evaluation: 7,178 test samples; accuracy 70.869323%; macro-F1 68.455860% (70.87% and 68.46% rounded).
- This run reevaluated the same Adaptive checkpoint and observed accuracy 70.869323% and macro-F1 68.455860%, matching the saved values.
- This agreement verifies the current evaluation output against the existing result file; it does not establish the legacy checkpoint training conditions.

## Metric definitions and methodology

- Accuracy: fraction of correct predictions. Balanced accuracy and macro precision/recall/F1 are unweighted averages across the seven classes. Weighted-F1 weights class F1 by support. Test loss is mean cross-entropy over test examples.
- Latency is measured around `forward_frame` only, after 3 warm-up batches; image loading and host-to-device transfer are excluded. CUDA synchronization brackets timed forwards. Throughput is the inverse of measured model-only time per image.
- Peak memory is PyTorch peak allocated memory during inference after model load; it excludes CUDA context and other non-PyTorch allocations.
- Checkpoint selection used validation results only. The official test set was evaluated after training and was not used for training or checkpoint selection.

## Artifacts

- Evaluation metrics, configs, and metadata: `evaluation/metrics.json` and `evaluation/metrics.csv`.
- Per-class report is included in `evaluation/metrics.csv`; raw per-image predictions are `evaluation/predictions_off.csv`, `predictions_fixed.csv`, and `predictions_adaptive.csv`.
- Confusion matrices: `evaluation/confusion_matrix.png` plus per-variant CSV matrices. Comparison plot: `evaluation/arwm_comparison.png`.
- Training curves: `results/arwm/off_20/training_curves.png` and `results/arwm/fixed_20/training_curves.png`.

## Limitations

- Adaptive training seed, duration, exact schedule, and original split provenance are unknown. Do not interpret the three-way ranking as a causal ablation or claim one mode is better based on this unmatched legacy comparison.
- Off vs Fixed were run with the same configured seed and training settings, but this is one seed/run per variant; no multi-seed uncertainty estimate is available.
- Latency and throughput are single-machine measurements and are not a deployment guarantee.

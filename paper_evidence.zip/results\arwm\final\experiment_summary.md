# ARWM Ablation Package ? Incomplete

**Status:** The Adaptive candidate is strictly compatible and has a complete official FER2013 test evaluation. A compatible Off checkpoint is unavailable, so the requested Off-versus-Adaptive ablation and causal conclusion are not complete. Fixed was not required for the two-way study and was not trained.

## Existing checkpoint provenance
- `checkpoints/best_model.pth`: epoch 18; Adaptive inferred from ARWM state keys and strictly loaded against the Adaptive config. Original training config/seed metadata is absent.
- `checkpoints/best_model_before_50epochs.pth`: epoch 5; also Adaptive by state-key signature and strictly loads; not a baseline checkpoint.
- Both contain 373 model-state entries, including the adaptive region MLP. Strict Off and Fixed compatibility fail because their models omit the MLP parameters. No checkpoint was overwritten.

## Newly evaluated Adaptive candidate
- Split: FER2013 official test; all 7,178 test images, image size 160, class order `anger, disgust, fear, happiness, sadness, surprise, neutral`.
- This is a new test evaluation, not a reproduction of the checkpoint-stored metrics. The checkpoint metrics are previously recorded values.
- Device: NVIDIA RTX 3050 Laptop GPU, CUDA; batch size 1, three warm-up passes.
- Timing is model-forward-only and excludes data loading and host-to-device transfer.

| Metric | Result |
|---|---:|
| Accuracy | 0.7087 |
| Balanced accuracy | 0.7099 |
| Macro precision | 0.6761 |
| Macro recall | 0.7099 |
| Macro F1 | 0.6846 |
| Weighted F1 | 0.7084 |
| Mean latency | 64.56 ms/image |
| Throughput | 15.49 images/s |
| Total parameters | 102,638,019 |
| Peak allocated GPU memory | 0.408 GiB |

### Per-class test results

| Class | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| anger | 0.6721 | 0.6033 | 0.6359 | 958 |
| disgust | 0.5029 | 0.7928 | 0.6154 | 111 |
| fear | 0.6555 | 0.4775 | 0.5525 | 1024 |
| happiness | 0.9242 | 0.8455 | 0.8831 | 1774 |
| sadness | 0.5587 | 0.6600 | 0.6051 | 1247 |
| surprise | 0.7685 | 0.8748 | 0.8182 | 831 |
| neutral | 0.6509 | 0.7153 | 0.6816 | 1233 |

## Adaptive region weights
- Measured on 7178 held-out test inputs; average weights eye/eyebrow/mouth = `[0.1222, 0.1187, 0.7591]`; standard deviations = `[0.1693, 0.2216, 0.2889]`.
- Maximum normalization error from sum-to-one: 1.42e-07.
- The positive standard deviations verify context-dependent variation in internal weights. These weights are not ground-truth explanations and do not prove causal benefit.

## Dataset and protocol
- Current folders contain 28,709 train images and 7,178 official-test images. The seeded loader partitions the train folder into 24,403 train and 4,306 validation images; path overlap across all three sets is zero.
- The folder loader performs a stratified image-level split; FER2013 subject identifiers are unavailable, so subject independence is not verified despite the config flag.
- Train and test remain separate. The training script ignores the official test loader.

## Training status and decision
- One-batch Off smoke passed on the actual batch size 32 for the frozen-backbone phase: train update, one validation batch, safe checkpoint save/reload, and strict state round-trip. A separate unfrozen batch-32 synthetic step peaked at 4.66 GiB and completed.
- No full epoch or variant training run was started. The measured unfrozen batch-32 compute step implies about 16.3 hours per 50-epoch variant before data loading, validation, and checkpoint I/O; two matched Off and Adaptive runs are estimated at more than 32 hours.
- Existing Adaptive is usable for exploratory evaluation, but absent seed/config metadata prevents certifying a controlled comparison with a newly trained Off model. Therefore no accuracy/F1 delta or claim of improvement is reported.

## Next commands (not executed)
```powershell
.\.venv\Scripts\python.exe scripts\train.py --config configs\arwm\off.yaml --arwm-mode off
.\.venv\Scripts\python.exe scripts\train.py --config configs\arwm\adaptive.yaml --arwm-mode adaptive
.\.venv\Scripts\python.exe scripts\evaluate_arwm_variants.py --config configs\config_arwm_50.yaml --off-checkpoint checkpoints\arwm_variants\off\best_model.pth --adaptive-checkpoint checkpoints\arwm_variants\adaptive\best_model.pth --output results\arwm\final\off_adaptive_eval
```

Fixed training is optional and should only be added for a three-way ablation. The evaluator refuses to overwrite non-empty output directories.

## Package contents
- `adaptive_existing/`: official-test metrics, confusion matrix, per-class CSV data, and region-weight distribution data/plot.
- `config_snapshots/`: base and adaptive YAML configurations.
- `experiment_inventory.json`: checkpoint, dataset, strict-load, and environment inventory.
- `training_preflight.json`: measured smoke and runtime estimate.
- No Off/Fixed metrics or comparison plot are included because those checkpoints are unavailable.

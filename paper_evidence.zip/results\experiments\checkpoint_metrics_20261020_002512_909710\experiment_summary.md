# Previously recorded checkpoint metrics

Exported: 2026-10-20T00:25:12.913536+05:30

These values were read from checkpoint metadata using safe loading. No model inference or metric recomputation was performed.

Units: accuracy, precision, recall, and macro F1 are percentages; balanced accuracy and ROC-AUC are fractions; loss is the stored validation mean loss. ARWM region statistics are dimensionless.

## best_model.pth

- Epoch: 18
- Metric source: previously recorded checkpoint metrics; not newly evaluated
- Stored metrics: `{"accuracy": 70.94751509521598, "arwm_eye_weight_mean": 0.12406623363494873, "arwm_eye_weight_std": 0.16820818185806274, "arwm_eyebrow_weight_mean": 0.11763356626033783, "arwm_eyebrow_weight_std": 0.22122585773468018, "arwm_mouth_weight_mean": 0.7583001852035522, "arwm_mouth_weight_std": 0.28654012084007263, "balanced_accuracy": 0.7044538664465876, "f1": 68.14169857727406, "mean_loss": 1.6390486118970093, "precision": 67.43175415083955, "recall": 70.44538664465875, "roc_auc": 0.9035572285284628}`

## best_model_before_50epochs.pth

- Epoch: 5
- Metric source: previously recorded checkpoint metrics; not newly evaluated
- Stored metrics: `{"accuracy": 64.00371574547144, "arwm_eye_weight_mean": 0.12029237300157547, "arwm_eye_weight_std": 0.1515820473432541, "arwm_eyebrow_weight_mean": 0.1876569539308548, "arwm_eyebrow_weight_std": 0.25873109698295593, "arwm_mouth_weight_mean": 0.6920506954193115, "arwm_mouth_weight_std": 0.28673675656318665, "balanced_accuracy": 0.6168954491969035, "f1": 59.75661088405878, "mean_loss": 1.5805249205342045, "precision": 58.82569759145903, "recall": 61.689544919690356, "roc_auc": 0.9088413947477452}`
